//DOM
document.body;

/////////////// Input Variables //////
const date_box = document.getElementById("date-box");
const date_input = document.getElementById("date-set");
const activity_dropdown_input = document.getElementById("activity-drop-down-box");
const for_word = document.getElementById("for");
const time_distance_text = document.getElementById("time-distance-box");
const time_distance_input = document.getElementById("time-distance");
const units_input = document.getElementById("units-box");
const submit_button = document.getElementById("submit-activity");
const activity_select = document.getElementById("activity-select");
let units_text = document.getElementById("units-text");
const activity_container = document.getElementById("add-activity");
const plans_container = document.getElementById("add-plans");

// setting future buttons to future variables
const f_activity = document.getElementById("future-activity-drop-down-box");
const f_activity_input = document.getElementById("future-activity-select");
const f_date = document.getElementById("future-date-box");
const f_submit = document.getElementById("submit-plans");
const f_date_input = document.getElementById("future-date-set");
// prompts variables
let f_prompt_container = document.getElementById("future-prompt");
let f_start_prompt = document.getElementById("future-start-prompt");
let f_normal_prompt = document.getElementById("future-normal-prompt");
let f_end_prompt = document.getElementById("future-end-prompt");

let current_date = new Date();
// let current_day = current_date.getDay();
// let current_month = current_date.getMonth();
// let current_year = current_date.getFullYear();
// console.log(current_day);
// console.log(current_month);
// console.log(current_year);

// prompts for answering
let prompt_container = document.getElementById("prompt");
let start_prompt = document.getElementById("start-prompt");
let normal_prompt = document.getElementById("normal-prompt");
let end_prompt = document.getElementById("end-prompt");

// hide prompt text
function hide_prompt(){
  prompt_container.style.display = "none";
  start_prompt.style.display = "none";
  normal_prompt.style.display = "none";
  end_prompt.style.display = "none";
}

// show prompt text
function show_prompt(){
  prompt_container.style.display = "unset";
  start_prompt.style.display = "unset";
  normal_prompt.style.display = "unset";
  end_prompt.style.display = "unset";
}


// hide past activity inputs
function hide_activity_inputs(){
time_distance_text.style.display = "none";
date_box.style.display = "none";
date_input.style.display = "none";
activity_dropdown_input.style.display = "none";
for_word.style.display = "none";
time_distance_input.style.display = "none";
units_input.style.display = "none";
submit_button.style.display = "none";
}

// show past activity inputs
function show_activity_inputs(){
date_box.style.display = "flex";
time_distance_text.style.display = "flex";
date_input.style.display = "flex";
activity_dropdown_input.style.display = "flex";
for_word.style.display = "flex";
time_distance_input.style.display = "flex";
units_input.style.display = "flex";
submit_button.style.display = "flex";
}

// add new past activity button turns invisible when clicked
const add_activity_button = document.getElementById("button-past-activity");
add_activity_button.addEventListener("click",(e) => {
  console.log("Activity Button Clicked");
  add_activity_button.style.display = "none";
  activity_container.style.flexFlow = "row wrap";
  show_activity_inputs();
  hide_prompt();
})

// submit button hides all past input boxes and shows add new activity
submit_button.addEventListener("click",(e) => {
  console.log("Activity Submit Button Clicked");
  if(check_past_error()){
    activity_error();
  } //checks for error
  else{
    hide_activity_inputs();
    add_activity_button.style.display = "flex";
    activity_container.style.flexFlow = "column wrap";
    show_prompt();
    activity_alert();

    //packs data into activity_data
    let activity_data = {
    input_date: date_input,
    input_activity: activity_select,
    input_time_distance: time_distance_input,
    }

    // Posting testing
    fetch('/newData', {
      method: 'POST',
      headers: {'Content-Type': 'text/plain'},
      body: JSON.stringify(activity_data) }) //items "struct" kinda
      .then(function(response){
        console.log("Got it! " + activity_select.value + " for " + time_distance_input.value + " " + units_text.value + ". Keep it up!")
        return response.text()
      })
      .then(function(data){
        console.log("activity data received: "+activity_data);
        //displayOutput(null, data); //idk what these do
      }).catch(function(error) {
        console.error('There has been a problem with your fetch operation',
        error);
        //displayOutput(null,error); //idk what these do
    });

  }


})


// updates units content
activity_select.addEventListener("change",(e) => {
  switch(e.target.value) {
  case "Bike":
    units_text.value = "Km";
    console.log("WORKS");
    break;
  case "Swim":
    units_text.value = "Laps"
    break;
  case "Run":
    units_text.value = "Km";
    break;
  case "Yoga":
    units_text.value = "Hours";
    break;
  case "Football":
    units_text.value = "Hours"
    break;
    // code block
 }
})

function activity_error(){
  alert("Invalid Past Activity. Please fill in the entire form.");
}

// Annoucing alert
function activity_alert(){
  start_prompt.textContent = "Got it! ";
  end_prompt.textContent = " Keep it up!";
  normal_prompt.textContent = activity_select.value + " for " + time_distance_input.value + " " + units_text.value + ".";
  show_prompt();
}

//Error testing
// if date is empty, if date is future, if time/distance isnt scalar, and time/distance isn't filled out
function check_past_error(){
  let input_date = new Date(date_input.value);
  input_date.setDate(input_date.getDate() + 1);
  input_date.setHours(0,0,0,0);
  console.log("current date:" + current_date);
  console.log("input date: "+ input_date);
  if(date_input.value == ""){
    console.log("no date error");
    return true;
  }
  if(input_date > current_date){
    console.log("date bigger");
    return true;
  }
  if(time_distance_input.value == ""){
    console.log("Time_distance empty")
    return true;
  }
  
  if(isNaN(time_distance_input.value)){
    console.log("Time_distance not number")
    return true;
  }
} 

//start state
hide_activity_inputs();
hide_prompt();
f_hide_prompt();
units_text.value = "Hours"

/////////////////////    Future Plans     ////////////////////////////////// 

// hide future activity inputs
function hide_plans_inputs(){
  f_activity.style.display = "none";
  f_date.style.display = "none";
  f_submit.style.display = "none";
}

// show future activity inputs
function show_plans_inputs(){
  f_activity.style.display = "flex";
  f_date.style.display = "flex";
  f_submit.style.display = "flex";
}

// hide future prompt text
function f_hide_prompt(){
  f_prompt_container.style.display = "none";
  f_start_prompt.style.display = "none";
  f_normal_prompt.style.display = "none";
  f_end_prompt.style.display = "none";
}

// show future prompt text
function f_show_prompt(){
  f_prompt_container.style.display = "unset";
  f_start_prompt.style.display = "unset";
  f_normal_prompt.style.display = "unset";
  f_end_prompt.style.display = "none"; // hidden for now
}

// add new future activity button turns invisible when clicked
const add_plans_button = document.getElementById("button-future-plans");
add_plans_button.addEventListener("click",(e) => {
  console.log("Add Plans Clicked");
  add_plans_button.style.display = "none";
  show_plans_inputs();
  f_hide_prompt();
  plans_container.style.flexFlow = "row wrap";
})

// checks date input error
function check_future_error(){
  let f_input_date = new Date(f_date_input.value);
  f_input_date.setDate(f_input_date.getDate() + 1);
  f_input_date.setHours(23,59,59,59);
  console.log("TEST: " + f_input_date.getDay());
  // f_input_date.setDate(f_input_date.getDate() + 1);
  // DATE IS BEING WACK
  // let temp = f_input_date.getDay()
  // temp+=1;
  // f_input_date.(temp);
  console.log("future plans current date:" + current_date);
  console.log("future plans input date: "+ f_input_date);
  if(f_date_input.value == ""){
    console.log("future plans: no date error");
    return true;
  }
  if(f_input_date < current_date){
    console.log("future plans: date smaller");
    return true;
  }
}

// error announcment
function plan_error(){
  alert("Invalid Future Plan. Please fill in the entire form.");
}

// Announcing alert
function plans_alert(){
  // f_start_prompt.textContent = "Sounds good! Don't forget to come back to update your session for ";
  f_normal_prompt.textContent = activity_select.value + " on " + f_date_input.value + "!";
  f_show_prompt();
}

// submit button for future plans 
// hides all future input boxes and shows add new activity
f_submit.addEventListener("click",(e) => {
  console.log("Future Plans Submit");
  if(check_future_error()){
    plan_error();
  }
  else{
    hide_plans_inputs();
    add_plans_button.style.display = "flex";
    plans_container.style.flexFlow = "column wrap";
    f_show_prompt();
    plans_alert();

    //packs data into activity_data
    let data = {
    input_date: date_input,
    input_activity: activity_select,
    input_time_distance: time_distance_input,
    }

    //packs data into activity_data
    let plans_data = {
    f_input_date: f_date_input,
    f_input_activity: f_activity_input,
    }

    // Posting testing
    fetch('/newData', {
      method: 'POST',
      headers: {'Content-Type': 'text/plain'},
      body: JSON.stringify(plans_data) }) //items "struct" kinda
      .then(function(response){
        console.log("Sounds good! Don't forget to come back to update your session for " + activity_select.value + " on " + f_date_input.value + "!");
        return response.text()
        //it's not returning it to anywhere, print it to console instead
      })
      .then(function(data){
        console.log("Future plans data recieved: "+plans_data);
        //displayOutput(null, data); //idk what these do
      }).catch(function(error) {
        console.error('There has been a problem with your fetch operation',
        error);
        //displayOutput(null,error); //idk what these do
    });

  }
})

hide_plans_inputs();

// hide_activity_inputs();
// add_activity_button.style.display = "flex";
// activity_container.style.flexFlow = "column wrap";
// show_prompt();
// activity_alert();


//start with button
// after submit show again

//get values from past input boxes and send request

// function postData() {
//   fetch('/newData', {
//     method: 'POST',
//     headers: {'Content-Type': },
//     body: items.toString() }) //items "struct" kinda
//     .then(function(response){
//       return response.text()
//     })
//     .then(function(data){
//       console.log("data received: "+data);
//       displayOutput(null, data);
//     }).catch(function(error) {
//       console.error('There has been a problem with your fetch operation',
//       error);
//       displayOutput(null,error);
//   });
// }

// let items = [];
// function buttonAction() {

// let past_date = date_input.value;
// let past_act = activity_dropdown_input.value;
// let past_time_dist = time_distance_input.value; 
// let past_units = units_input.value;

// }

//get values from future input boxes and send request






//fetch
//input vallidation
//date cannot be tommorow+




// temp hidden because Im not sure what activity_submit does
// //submit button makes "add new activity" button visiable
// let activity_submit = document.getElementById("submit-activity");
// activity_submit.addEventListener("click",(e) => {
//   console.log("Clicked");
//   activity_past.style.display = "flex";
//   // activity_past.style.display = "none"
// })



/*let past = document.getElementsByID("add-activity");
let future = document.getElementsByClassName("add-plans");
past.textContent = 'testing 1';
future.textContent = 'testing 2';
*/


/* TESTING SO I PUT YOUR OLD CODE HERE AS A BACKUP

//Requests
//when past submit button is hit, send Requests
//if everything is filled in properly
const past_submit = document.getElementById("submit-activity");
past_submit.addEventListener("click", buttonAction);

function buttonAction(){
  let date = document.getElementsByClassName("date-set").value;
  let time_dist = document.getElementsByClassName("time-distance").value;
  let activity = document.getElementsByClassName("activity-select").value;
  let units = document.getElementsByClassName("units").value;
  console.log("We got", date, time_dist, activity, units);
}
// past_submit.onclick = () => {
//   //erase previous content
//   past.textContent = 'Got it! ________. Keep it up!'; //____ should be bolded

//   //add new activity button
// }
//else send error

//when future submit button is hit, send Requests
let future_submit = document.getElementById("");
future_submit.onclick = () => {
  future.textContent = "Sounds good! Don't forget to come back to update your session for ___!";//bold text for "_____"

  //add new activity button
}

*/