Team:
* Sadia Mahtaban - smahtaban@ucdavis.edu
* An Ho - hoaho@ucdavis.edu
* Chris Cruz - ccruz@ucdavis.edu
---
Notes:
* We tried to make dynamic components, but since we kept running into errors, we had to eventually hardcode HTML and CSS elements.
* We had issues with the reset button. In theory, we wanted to use hooks go back to state 0 when the user pressed it.
  * We resorted to reloading the page entirely.
* We were having issues with connecting the user input with the pie charts. Ideally, we would have the input elements update the cooresponding values in the JSON.