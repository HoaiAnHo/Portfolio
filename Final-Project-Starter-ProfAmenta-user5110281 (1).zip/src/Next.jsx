import React, { useRef, useEffect, useState } from 'react';

//count and setcount
//also move this to app.jsx function

//also maybe props?

function NextButton(props){

 function nextHandler(){
   props.increment();

 }
  return (
    <button id="nextButton" onClick={nextHandler}>Next</button>

  )
  console.log("click")
}



export default NextButton;