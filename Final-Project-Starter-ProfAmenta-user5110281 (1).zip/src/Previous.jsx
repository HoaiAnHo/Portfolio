// function PreviousButton(props) {
//   // if at state 2
//   return (
//     <div>
//       <button onClick={() => props.dec()}>
//         Next
//       </button>
//     </div>
//     //return a different button
//   )
//       // reload the previous input data and draw the pie chart with that again
//       // hide the user-input expenses pie chart
//       // line 1 and circle 2 are changed from blue to grey
// }

import React, { useRef, useEffect, useState } from 'react';

//count and setcount
//also move this to app.jsx function

//also maybe props?

function PreviousButton(props){

 function previousHandler(){
   props.decrement()

 }
  return (
    <button id="previous-button" onClick={previousHandler}>Previous</button>

  )
}



export default PreviousButton;