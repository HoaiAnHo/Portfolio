
import React, { useRef, useEffect, useState } from 'react';
import ReactTooltip from 'react-tooltip';
import Header from "./Header.jsx";
import PieChart from "./D3PieComponent.jsx";


import NextButton from "./Next.jsx";
import PreviousButton from "./Previous.jsx";
import CompareButton from "./Compare.jsx";
import ResetButton from "./Reset.jsx";
import LegendBox from "./LegendBox.jsx"
import LegendBox2 from "./LegendBox2.jsx"
import './App.css';





/* App */
function App() {


  const [state, setState] = useState(0);
  //try renaming count as state or view
  //this indicates states (for button click)
  //revenue=0, expenses=1, etc

  function increment() {
    setState(state + 1);
  }

  function decrement() {
    setState(state - 1);
  }

  function reset() {
    setState(state - 3);
  }

  // data on Unversity income
  let revenueData =
    [
      { name: "Medical Center", value: 45, color: "#F0BF00" },
      { name: "Student Fees", value: 4, color: "#F6E50E" },
      { name: "State of California", value: 8, color: "#FFF688" },
      { name: "Tuition", value: 11, color: "#5F63EC" },
      { name: "Research Grants and Contracts", value: 13, color: "#71A8FF" },
      { name: "Pell Grants", value: 1, color: "#58C9FB" },
      { name: "Non-educational Services", value: 11, color: "#0F7AB4" },
      { name: "Gifts, Endowments, Interest, Etc.", value: 7, color: "#D4E4FF" }
    ];

  let expenditureData =
    [
      { name: "Medical Center", value: 43, color: "#F0BF00" },
      { name: "Teaching and Teaching Support", value: 23, color: "#F6E50E" },
      { name: "Research", value: 11, color: "#FFF688" },
      { name: "Student Services and Financial Aid", value: 8, color: "#5F63EC" },
      { name: "Operations and Maintenance (Buildings, etc)", value: 2, color: "#71A8FF" },
      { name: "Administration", value: 3, color: "#58C9FB" },
      { name: "Non-Educational Services", value: 2, color: "#0F7AB4" },
      { name: "Public Service", value: 2, color: "#D4E4FF" },
      { name: "Depreciation, Interest, etc.", value: 6, color: "#ffffff" }
    ];

  let dataInput = [
    { name: "Medical Center", value: 0, color: "#F0BF00" },
    { name: "Student Fees", value: 0, color: "#F6E50E" },
    { name: "State of California", value: 0, color: "#FFF688" },
    { name: "Tuition", value: 0, color: "#5F63EC" },
    { name: "Research Grants and Contracts", value: 0, color: "#71A8FF" },
    { name: "Pell Grants", value: 0, color: "#58C9FB" },
    { name: "Non-educational Services", value: 0, color: "#0F7AB4" },
    { name: "Gifts, Endowments, Interest, Etc.", value: 0, color: "#D4E4FF" }
  ];


  const [pieData1, setPieData1] = useState(revenueData);
  const [pieData2, setPieData2] = useState(expenditureData);

  const resetPie = () => setPieData1(dataInput);



  if (state == 0) {
    return (
      <div>

        <div className="Header">
          <Header />
        </div>


        <div id="progress">

          <div>
            <label for="circle1">REVENUES</label>
            <div id="circle1"></div>
          </div>
          <div id="bar1" style={
            { borderTop: "4px solid #7f8187 ", marginLeft: -46.9, marginRight: -40, width: 260, marginTop: 49 }
          }>
          </div>

          <div>
            <label for="circle2">EXPENSES</label>
            <div id="circle2"></div>
          </div>

          <div id="bar2" style={
            { borderTop: "4px solid #7f8187 ", marginLeft: -33.28, marginRight: -40, width: 260, marginTop: 49 }
          }>
          </div>

          <div>
            <label for="circle3">COMPARE</label>
            <div id="circle3"></div>
          </div>

        </div>


        <h2>UC Davis Revenues</h2>
        <div className="pie-chart">
          <PieChart name={"pie1"} data={pieData1} />


        </div>

        <LegendBox />


        <div id="center">
          <NextButton increment={increment}></NextButton>
        </div>
      </div>
    );
  }
  //////////////////////////////////////////////////////////////////////////  
  else if (state == 1) {
    return (
      <div>

        <div className="Header">
          <Header />
        </div>





        <div id="progress">
          <div>
            <label for="circle1">REVENUES</label>
            <div id="circle1"></div>
          </div>

          <div id="bar1" style={
            { borderTop: "4px solid #71a8ff ", marginLeft: -46.9, marginRight: -40, width: 260, marginTop: 49 }
          }>
          </div>

          <div>

            <label for="circle2">EXPENSES</label>
            <div id="circle2" style={{ backgroundColor: "#71a8ff" }}></div>
          </div>

          <div id="bar2" style={
            { borderTop: "4px solid #7f8187 ", marginLeft: -33.28, marginRight: -40, width: 260, marginTop: 49 }
          }>
          </div>
          <div>
            <label for="circle3">COMPARE</label>
            <div id="circle3"></div>
          </div>

        </div>


        <h2>UC Davis Expenditures</h2>
        <div className="pie-chart">

          <PieChart name={"pie3"} data={expenditureData} />
        </div>



        <LegendBox2 />


        <div id="center">
          <CompareButton increment={increment} />

        </div>
        <div id="center">
          <PreviousButton decrement={decrement} />
        </div>

      </div>
    );
  }
  //////////////////////////////////////////////////////////////////////////  
  else if (state == 2) {
    return (
      <div>

        <div className="Header">
          <Header />
        </div>

        <div id="progress">
          <div>
            <label for="REVENUES">REVENUES</label>
            <div id="circle1"></div>
          </div>

          <div id="bar1" style={
            { borderTop: "4px solid #71a8ff ", marginLeft: -46.9, marginRight: -40, width: 260, marginTop: 49 }
          }>
          </div>
          <div>
            <label for="EXPENSES">EXPENSES</label>
            <div id="circle2" style={{ backgroundColor: "#71a8ff" }}></div>
          </div>

          <div id="bar2" style={
            { borderTop: "4px solid #71a8ff ", marginLeft: -33.28, marginRight: -40, width: 260, marginTop: 49 }
          }>
          </div>
          <div>
            <label for="COMPARE">COMPARE</label>
            <div id="circle3" style={{ backgroundColor: "#71a8ff" }}></div>
          </div>
        </div>


        <h2>RESULTS</h2>
        <div className="pie-chart">
          <PieChart name={"pie1"} data={pieData1} />
          <PieChart name={"pie2"} data={pieData2} />

        </div>

        <div id="center">
        <NextButton increment={increment} />
         
        </div>

        <div id="center" >
           <PreviousButton decrement={decrement} />
        </div>

      </div>
    );
  }
  else if (state == 3) {
    return (
      <div>

        <div className="Header">
          <Header />
        </div>

        <div id="progress">
          <div>
            <label for="REVENUES">REVENUES</label>
            <div id="circle1"></div>
          </div>

          <div id="bar1" style={
            { borderTop: "4px solid #71a8ff ", marginLeft: -46.9, marginRight: -40, width: 260, marginTop: 49 }
          }>
          </div>
          <div>
            <label for="EXPENSES">EXPENSES</label>
            <div id="circle2" style={{ backgroundColor: "#71a8ff" }}></div>
          </div>

          <div id="bar2" style={
            { borderTop: "4px solid #71a8ff ", marginLeft: -33.28, marginRight: -40, width: 260, marginTop: 49 }
          }>
          </div>
          <div>
            <label for="COMPARE">COMPARE</label>
            <div id="circle3" style={{ backgroundColor: "#71a8ff" }}></div>
          </div>
        </div>


        <h2>RESULTS</h2>
        <div className="pie-chart">
          <PieChart name={"pie1"} data={pieData1} />
          <PieChart name={"pie2"} data={pieData2} />

        </div>

        <div id="center">
          <ResetButton reset={reset} />
        </div>

      </div>
    );
  }


}

export default App;

//need to figure out how to style this and how to put it into js stuff above



// state 0:
  //next stuff is drawn in app.jsx
    // line 1 and circle 2 are changed from grey to blue (NEXT DOESN'T ACTUALLY DRAW FOR PROGRESS BAR)
    // <div id="bar1" style={
    // { borderTop: "5px solid #71a8ff ", marginLeft: -2, marginRight: -2, width: 230 }
    // }>
    // </div>

    //hide user-input revenue pie chart
    //display user-input expenses pie chart (initially empty)

  //if at state 3
    //move onto state 3.5

      //hide user-input revenue pie chart
      //hide given revenue pie chart

      //display user-input expenses pie chart
      //display given expenses pie chart


  //move to state 3
      // line 2 and circle 3 are changed from grey to blue

      //remove input areas

      //display "RESULTS" at top

      //initial = draw preset revenue data chart and current revenue data chart

/////////////////
