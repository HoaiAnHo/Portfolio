// function RestartButton(props) {
//   //if at state 3.5 = wipe out user-given input data and move to state 1
//   return (
//     <div>
//       <button onClick={() => props.reset()}>
//         Next
//       </button>
//     </div>
//     //return a different button
//   )
//   //wipe out user-given input data
// }
import React, { useRef, useEffect, useState } from 'react';

//count and setcount
//also move this to app.jsx function

//also maybe props?

function ResetButton(props){

 function resetHandler(){
   props.current.reset();

 }
  return (
    <button id="reset-button" onClick={resetHandler}>Restart</button>

  )
}



export default ResetButton;