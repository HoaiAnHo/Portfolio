// function CompareButton(props) {
//   // if at state 2
//   return (
//     <div>
//       <button onClick={() => props.inc()}>
//         Next
//       </button>
//     </div>
//     //return a different button
//   )
      
// }

import React, { useRef, useEffect, useState } from 'react';

//count and setcount
//also move this to app.jsx function

//also maybe props?

function CompareButton(props){

 function CompareHandler(){
   props.increment()

 }
  return (
    <button id="compare-button" onClick={CompareHandler}>Compare</button>

  )
}



export default CompareButton;